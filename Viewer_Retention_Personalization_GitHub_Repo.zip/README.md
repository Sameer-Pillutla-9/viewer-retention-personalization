# Viewer Engagement, Retention, and Personalization Opportunity Model

> **Portfolio disclosure:** This repository uses synthetic session data and aggregate-style video metadata. It is a methodology portfolio, not a representation of any platform's private viewer data or recommendation systems.

## Five-point project description

1. **Business problem:** Identify content, creative, and audience factors associated with deeper viewing, repeat engagement, and reactivation opportunity.
2. **Data model:** Build separate video, session, and viewer tables that resemble an analytics warehouse while avoiding personal or sensitive data.
3. **Behavioral analytics:** Calculate cohorts, retention curves, viewing-depth distributions, repeat-viewing rates, and audience segments.
4. **Predictive prioritization:** Train an interpretable churn-risk model, review calibration, and convert model features into candidate personalization or campaign hypotheses.
5. **Actionability and safeguards:** Include segment scorecards, fairness/sampling checks, monitoring metrics, and explicit guidance not to use the model for sensitive-targeting decisions.

## Repository structure

```text
├── data/
│   └── generate_synthetic_viewer_data.py
├── sql/
│   └── 01_viewer_engagement_mart.sql
├── src/
│   └── analyze_retention.py
├── docs/
│   └── dashboard_spec.md
├── tests/
│   └── test_retention.py
└── requirements.txt
```

## Run locally

```bash
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt
python data/generate_synthetic_viewer_data.py
python src/analyze_retention.py
pytest -q
```

## What to discuss in an interview

- Why retention needs a clear cohort definition and observation window.
- Why correlation between a format feature and retention does not establish causal impact.
- Why calibrated risk scores are more useful for business prioritization than raw probabilities.
- How you would use randomized creative or message tests before implementing personalization at scale.
- How you would protect privacy, avoid sensitive inference, and monitor segment-level model performance.

## Resume claim only after completion

Built a BigQuery-ready viewer engagement and retention analysis using Python and SQL to identify content, creative, and audience signals associated with repeat viewing and reactivation. Produced cohort, survival-style retention, segmentation, and calibrated churn-risk analyses that translated behavioral patterns into measurable personalization hypotheses.
