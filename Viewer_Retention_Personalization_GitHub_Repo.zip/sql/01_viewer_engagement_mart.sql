-- BigQuery Standard SQL: construct a reusable viewer engagement mart.
CREATE OR REPLACE TABLE `project.dataset.viewer_engagement_mart` AS
WITH session_enriched AS (
  SELECT
    s.user_id,
    s.session_id,
    DATE(s.session_date) AS session_date,
    s.watch_pct,
    s.minutes_watched,
    s.acquisition_channel,
    s.initial_intent,
    v.content_format,
    v.topic,
    v.creator_tier,
    MIN(DATE(s.session_date)) OVER (PARTITION BY s.user_id) AS first_session_date
  FROM `project.dataset.sessions` s
  JOIN `project.dataset.videos` v USING (video_id)
)
SELECT
  user_id,
  DATE_TRUNC(first_session_date, MONTH) AS cohort_month,
  COUNT(*) AS sessions,
  AVG(watch_pct) AS avg_watch_pct,
  SUM(minutes_watched) AS minutes_watched,
  AVG(IF(content_format = 'live', 1, 0)) AS live_share,
  AVG(IF(content_format = 'short', 1, 0)) AS short_share,
  AVG(IF(creator_tier = 'flagship', 1, 0)) AS flagship_creator_share,
  ANY_VALUE(acquisition_channel) AS acquisition_channel,
  ANY_VALUE(initial_intent) AS initial_intent
FROM session_enriched
GROUP BY user_id, cohort_month;
