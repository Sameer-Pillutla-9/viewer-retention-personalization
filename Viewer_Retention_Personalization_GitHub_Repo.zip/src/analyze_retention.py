"""Create cohort, retention, segmentation, and churn-risk artifacts from synthetic viewer data."""
from __future__ import annotations

from pathlib import Path
import json
import numpy as np
import pandas as pd
from sklearn.cluster import KMeans
from sklearn.compose import ColumnTransformer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import brier_score_loss, roc_auc_score
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler

ROOT = Path(__file__).resolve().parents[1]
DATA_DIR = ROOT / "data"
OUTPUT_DIR = ROOT / "output"


def build_user_features(sessions: pd.DataFrame, videos: pd.DataFrame) -> pd.DataFrame:
    data = sessions.merge(videos, on="video_id", how="left")
    data["session_date"] = pd.to_datetime(data["session_date"])
    first = data.groupby("user_id")["session_date"].min().rename("first_session")
    data = data.merge(first, on="user_id")
    data["days_since_first"] = (data["session_date"] - data["first_session"]).dt.days
    user = data.groupby("user_id").agg(
        cohort_month=("first_session", lambda s: str(s.min().to_period("M"))),
        sessions=("session_id", "count"),
        avg_watch_pct=("watch_pct", "mean"),
        minutes_watched=("minutes_watched", "sum"),
        live_share=("content_format", lambda s: float((s == "live").mean())),
        short_share=("content_format", lambda s: float((s == "short").mean())),
        creator_flagship_share=("creator_tier", lambda s: float((s == "flagship").mean())),
        acquisition_channel=("acquisition_channel", "first"),
        initial_intent=("initial_intent", "first"),
        churn_30d=("churn_30d", "max"),
    ).reset_index()
    return user


def make_cohort_table(sessions: pd.DataFrame) -> pd.DataFrame:
    sessions = sessions.copy()
    sessions["session_date"] = pd.to_datetime(sessions["session_date"])
    first = sessions.groupby("user_id")["session_date"].min().rename("first_session")
    sessions = sessions.merge(first, on="user_id")
    sessions["week_number"] = ((sessions["session_date"] - sessions["first_session"]).dt.days // 7).astype(int)
    sessions["cohort_month"] = sessions["first_session"].dt.to_period("M").astype(str)
    active = sessions.groupby(["cohort_month", "week_number"])["user_id"].nunique().rename("active_users").reset_index()
    cohort_size = active.query("week_number == 0")[["cohort_month", "active_users"]].rename(columns={"active_users": "cohort_size"})
    output = active.merge(cohort_size, on="cohort_month")
    output["retention_rate"] = output["active_users"] / output["cohort_size"]
    return output


def main() -> None:
    OUTPUT_DIR.mkdir(exist_ok=True)
    sessions = pd.read_csv(DATA_DIR / "sessions.csv")
    videos = pd.read_csv(DATA_DIR / "videos.csv")
    user = build_user_features(sessions, videos)
    cohorts = make_cohort_table(sessions)

    clustering_features = ["sessions", "avg_watch_pct", "minutes_watched", "live_share", "short_share"]
    scaled = StandardScaler().fit_transform(user[clustering_features])
    user["segment_id"] = KMeans(n_clusters=4, random_state=42, n_init=20).fit_predict(scaled)
    segment_names = {0: "high_depth", 1: "casual_explorers", 2: "short_form_regulars", 3: "live_event_fans"}
    user["audience_segment"] = user["segment_id"].map(segment_names)

    feature_cols = [
        "sessions", "avg_watch_pct", "minutes_watched", "live_share", "short_share", "creator_flagship_share",
        "acquisition_channel", "initial_intent",
    ]
    numeric = [c for c in feature_cols if c not in {"acquisition_channel", "initial_intent"}]
    categorical = ["acquisition_channel", "initial_intent"]
    X_train, X_test, y_train, y_test = train_test_split(
        user[feature_cols], user["churn_30d"], test_size=0.25, stratify=user["churn_30d"], random_state=42
    )
    model = Pipeline(
        [
            ("prep", ColumnTransformer([("num", StandardScaler(), numeric), ("cat", OneHotEncoder(handle_unknown="ignore"), categorical)])),
            ("logit", LogisticRegression(max_iter=1000, class_weight="balanced", random_state=42)),
        ]
    )
    model.fit(X_train, y_train)
    probs = model.predict_proba(X_test)[:, 1]
    metrics = {"test_roc_auc": float(roc_auc_score(y_test, probs)), "test_brier_score": float(brier_score_loss(y_test, probs))}
    user["churn_risk"] = model.predict_proba(user[feature_cols])[:, 1]

    scorecard = user.groupby("audience_segment").agg(
        users=("user_id", "count"), avg_watch_pct=("avg_watch_pct", "mean"), avg_churn_risk=("churn_risk", "mean"), churn_rate=("churn_30d", "mean")
    ).reset_index().sort_values("avg_churn_risk", ascending=False)
    cohorts.to_csv(OUTPUT_DIR / "cohort_retention.csv", index=False)
    scorecard.to_csv(OUTPUT_DIR / "segment_scorecard.csv", index=False)
    user.to_csv(OUTPUT_DIR / "viewer_features_and_risk.csv", index=False)
    (OUTPUT_DIR / "model_metrics.json").write_text(json.dumps(metrics, indent=2), encoding="utf-8")
    print("Model metrics:", json.dumps(metrics, indent=2))
    print("\nSegment scorecard:\n", scorecard.to_string(index=False))


if __name__ == "__main__":
    main()
