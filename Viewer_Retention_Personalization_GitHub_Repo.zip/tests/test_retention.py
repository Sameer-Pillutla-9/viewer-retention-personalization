from pathlib import Path
import sys
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
sys.path.append(str(ROOT / "src"))
from analyze_retention import make_cohort_table


def test_cohort_retention_is_bounded():
    sessions = pd.DataFrame(
        {
            "user_id": [1, 1, 2, 2],
            "session_id": ["a", "b", "c", "d"],
            "session_date": ["2025-01-01", "2025-01-08", "2025-01-01", "2025-01-15"],
        }
    )
    cohort = make_cohort_table(sessions)
    assert cohort["retention_rate"].between(0, 1).all()
