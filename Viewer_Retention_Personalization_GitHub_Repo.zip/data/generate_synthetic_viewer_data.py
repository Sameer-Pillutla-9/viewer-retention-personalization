"""Generate synthetic video metadata and viewer sessions for retention analysis."""
from __future__ import annotations

from pathlib import Path
import numpy as np
import pandas as pd

RNG = np.random.default_rng(123)
ROOT = Path(__file__).resolve().parents[1]
DATA_DIR = ROOT / "data"


def sigmoid(x: np.ndarray) -> np.ndarray:
    return 1.0 / (1.0 + np.exp(-x))


def main(n_videos: int = 700, n_users: int = 6000) -> None:
    DATA_DIR.mkdir(exist_ok=True)
    video_id = np.arange(1, n_videos + 1)
    content_format = RNG.choice(["short", "long_form", "live"], n_videos, p=[0.38, 0.48, 0.14])
    topic = RNG.choice(["sports", "music", "entertainment", "education", "gaming"], n_videos)
    creator_tier = RNG.choice(["emerging", "established", "flagship"], n_videos, p=[0.55, 0.34, 0.11])
    duration_minutes = np.where(
        content_format == "short",
        RNG.uniform(0.3, 1.0, n_videos),
        np.where(content_format == "live", RNG.uniform(20, 150, n_videos), RNG.uniform(5, 35, n_videos)),
    )
    creative_energy = RNG.normal(0, 1, n_videos)
    videos = pd.DataFrame(
        {
            "video_id": video_id,
            "content_format": content_format,
            "topic": topic,
            "creator_tier": creator_tier,
            "duration_minutes": duration_minutes.round(2),
            "creative_energy_z": creative_energy.round(3),
        }
    )
    videos.to_csv(DATA_DIR / "videos.csv", index=False)

    users = pd.DataFrame(
        {
            "user_id": np.arange(1, n_users + 1),
            "acquisition_channel": RNG.choice(["organic", "paid_social", "creator", "search"], n_users, p=[0.42, 0.18, 0.24, 0.16]),
            "initial_intent": RNG.choice(["lean_back", "purposeful", "live_event"], n_users, p=[0.5, 0.36, 0.14]),
            "baseline_affinity": RNG.normal(0, 1, n_users),
            "signup_date": pd.Timestamp("2025-01-01") + pd.to_timedelta(RNG.integers(0, 180, n_users), unit="D"),
        }
    )
    topic_to_idx = {value: np.flatnonzero(topic == value) for value in np.unique(topic)}
    session_rows: list[dict[str, object]] = []
    all_idx = np.arange(n_videos)
    for user in users.itertuples(index=False):
        session_count = int(np.clip(RNG.poisson(5 + 2 * max(user.baseline_affinity, -1)), 1, 18))
        preferred_topic = str(RNG.choice(list(topic_to_idx)))
        for session_number in range(session_count):
            video_index = int(RNG.choice(topic_to_idx[preferred_topic] if RNG.random() < 0.70 else all_idx))
            format_bonus = 0.22 if content_format[video_index] == "live" and user.initial_intent == "live_event" else 0.0
            watch_pct = float(np.clip(
                RNG.normal(0.52 + 0.11 * user.baseline_affinity + 0.09 * creative_energy[video_index] + format_bonus, 0.22),
                0.02,
                1.0,
            ))
            session_date = user.signup_date + pd.Timedelta(days=int(RNG.integers(0, 70)))
            session_rows.append(
                {
                    "user_id": user.user_id,
                    "session_id": f"{user.user_id}-{session_number + 1}",
                    "session_date": session_date.date().isoformat(),
                    "video_id": int(video_id[video_index]),
                    "watch_pct": round(watch_pct, 4),
                    "minutes_watched": round(float(watch_pct * duration_minutes[video_index]), 3),
                    "acquisition_channel": user.acquisition_channel,
                    "initial_intent": user.initial_intent,
                }
            )
    session_df = pd.DataFrame(session_rows)
    session_df["session_date_dt"] = pd.to_datetime(session_df["session_date"])
    first_seen = session_df.groupby("user_id")["session_date_dt"].min().rename("first_session_dt")
    session_df = session_df.merge(first_seen, on="user_id")
    session_df["day_since_first"] = (session_df["session_date_dt"] - session_df["first_session_dt"]).dt.days
    user_14d = session_df.query("day_since_first <= 14").groupby("user_id").agg(
        sessions_14d=("session_id", "count"), avg_watch_pct_14d=("watch_pct", "mean"), minutes_14d=("minutes_watched", "sum")
    )
    user_30d = session_df.query("day_since_first.between(15, 45)").groupby("user_id").size().rename("later_sessions")
    labels = user_14d.join(user_30d, how="left").fillna({"later_sessions": 0}).reset_index()
    labels["churn_30d"] = (labels["later_sessions"] == 0).astype(int)
    session_df = session_df.merge(labels[["user_id", "churn_30d"]], on="user_id", how="left")
    session_df.drop(columns=["session_date_dt", "first_session_dt", "day_since_first"], inplace=True)
    session_df.to_csv(DATA_DIR / "sessions.csv", index=False)
    print(f"Wrote {len(videos):,} videos and {len(session_df):,} sessions")


if __name__ == "__main__":
    main()
