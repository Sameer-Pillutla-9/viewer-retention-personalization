# Portfolio evidence checklist

Before publishing, add a concise executive memo, one dashboard screenshot, and a rendered summary of your actual outputs. Keep the synthetic-data disclosure visible. Do not overstate observational correlations or synthetic outputs as production performance.
