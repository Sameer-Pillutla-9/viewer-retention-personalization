# Dashboard specification: Viewer Growth and Retention

## Primary audiences

Marketing leads, creator partnerships, product growth, and analytics stakeholders.

## Core pages

1. **Executive overview:** weekly active viewers, 7-day retention, 30-day churn rate, repeat viewing, and top cohort trends.
2. **Cohort retention:** acquisition-channel cohorts by week since first session, with volume and retention-rate toggle.
3. **Audience segments:** segment size, viewing depth, churn risk, content preference, and recommended next experiment.
4. **Content/creative signals:** format/topic/creator-tier associations. Label these as observational, not causal.
5. **Experiment monitoring:** treatment/control sample size, guardrails, pre-registered success metrics, and decision log.

## Guardrails

- Do not include direct identifiers.
- Do not infer sensitive attributes.
- Use aggregate reporting thresholds and clear observation windows.
- Treat segment recommendations as hypotheses until validated through experimentation.
